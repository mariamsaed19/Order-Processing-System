package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JScrollPane;

import java.awt.Color;
import java.awt.Cursor;

import javax.swing.AbstractListModel;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Orders {

	private JFrame frame;
	private JList list;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Orders window = new Orders();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Orders() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1367, 756);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblPlaceOrder = new JLabel("Orders");
		lblPlaceOrder.setBounds(25, 23, 206, 52);
		lblPlaceOrder.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 30));
		frame.getContentPane().add(lblPlaceOrder);
		
		String data[][]={ {"    Journey To the center of earth","25","1-5-2021"},    
	                {"    Beat again","10","12-8-2021"},    
	                {"    Blood sweat and tears","11","1-9-2022"}};    
		String column[]={"Book ISBN","Copies","Date"};
		JScrollPane sp=new JScrollPane();
		sp.setBounds(109, 118, 1162, 500);
		frame.getContentPane().add(sp);   
		
		table = new JTable() ;
		table.setFillsViewportHeight(true);
		table.setFocusable(false);
		table.setFocusTraversalKeysEnabled(false);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setDefaultEditor(Object.class, null);
		table.setVerifyInputWhenFocusTarget(false);
		table.setUpdateSelectionOnSort(false);
		table.setFont(new Font("Tahoma", Font.PLAIN, 25));
		table.setModel(new DefaultTableModel(
				data,
			column
		) {
			
		});
		table.setAlignmentX(SwingConstants.CENTER);
		JTableHeader header = table.getTableHeader();
		header.setFont(new Font("Tahoma", Font.PLAIN, 25));
		header.setOpaque(false);
		table.setRowHeight(40);
		sp.setViewportView(table);
		
		JButton confirmbtn = new JButton("Confirm Order");
		confirmbtn.setFont(new Font("Tahoma", Font.BOLD, 15));
		confirmbtn.setFocusPainted(false);
		confirmbtn.setBounds(1107, 659, 169, 50);
		Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
        confirmbtn.setCursor(cursor);
		frame.getContentPane().add(confirmbtn);
		
		JButton backbtn = new JButton("Back");
		backbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				Search.main(null);
			}
		});
		backbtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		backbtn.setBounds(31, 667, 85, 30);
		backbtn.setFocusPainted(false);
		backbtn.setCursor(cursor);
		frame.getContentPane().add(backbtn);
		
		JButton neworderbtn = new JButton("Place new order");
		neworderbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PlaceOrder.main(null);
			}
		});
		neworderbtn.setActionCommand("");
		neworderbtn.setFont(new Font("Tahoma", Font.BOLD, 15));
		neworderbtn.setFocusPainted(false);
		neworderbtn.setBounds(1102, 48, 169, 50);
		neworderbtn.setFocusPainted(false);
		neworderbtn.setCursor(cursor);
		frame.getContentPane().add(neworderbtn);
	}
}
