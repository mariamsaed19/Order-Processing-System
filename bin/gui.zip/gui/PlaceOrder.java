package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JButton;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.DefaultComboBoxModel;

public class PlaceOrder {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlaceOrder window = new PlaceOrder();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PlaceOrder() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 827, 356);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Beat Again", "Journey to the center of earth", "Oliver Twist", "Prisoner of zenda", "Fake love"}));
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
		comboBox.setBounds(242, 146, 419, 45);
		AutoCompletion.enable(comboBox);
		frame.getContentPane().add(comboBox);
		
		JLabel lblChooseBook = new JLabel("Choose Book");
		lblChooseBook.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChooseBook.setBounds(70, 150, 134, 33);
		frame.getContentPane().add(lblChooseBook);
		
		JLabel lblPlaceNewOrder = new JLabel("Place new Order");
		lblPlaceNewOrder.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 30));
		lblPlaceNewOrder.setBounds(70, 10, 328, 52);
		frame.getContentPane().add(lblPlaceNewOrder);
		
		JLabel lblNewLabel_1_1 = new JLabel("Type first characters of book name to autocomplete");
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_1.setBounds(285, 98, 459, 19);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("Hint :");
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(242, 98, 56, 19);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnOrder = new JButton("Order");
		btnOrder.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnOrder.setFocusPainted(false);
		btnOrder.setBounds(655, 264, 122, 30);
		btnOrder.setCursor(cursor);
		btnOrder.setFocusPainted(false);
		frame.getContentPane().add(btnOrder);
		
		JLabel lblChooseQuantity = new JLabel("Choose Quantity");
		lblChooseQuantity.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChooseQuantity.setBounds(70, 222, 162, 33);
		frame.getContentPane().add(lblChooseQuantity);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		spinner.setBounds(242, 222, 134, 31);
		frame.getContentPane().add(spinner);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

}
