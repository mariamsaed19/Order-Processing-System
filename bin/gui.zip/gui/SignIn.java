package gui;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class SignIn {

	private JFrame frame;
	private JTextField usernameField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignIn window = new SignIn();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SignIn() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
		frame = new JFrame();
		frame.setBounds(100, 100, 869, 632);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel titlelbl = new JLabel("Sign In");
		titlelbl.setFont(new Font("Tahoma", Font.PLAIN, 70));
		titlelbl.setBounds(295, 29, 264, 85);
		frame.getContentPane().add(titlelbl);
		
		JLabel usernamelbl = new JLabel("Username");
		usernamelbl.setFont(new Font("Tahoma", Font.PLAIN, 25));
		usernamelbl.setBounds(64, 259, 131, 31);
		frame.getContentPane().add(usernamelbl);
		
		JLabel passwordlbl = new JLabel("Password");
		passwordlbl.setFont(new Font("Tahoma", Font.PLAIN, 25));
		passwordlbl.setBounds(64, 334, 131, 31);
		frame.getContentPane().add(passwordlbl);
		
		usernameField = new JTextField();
		usernameField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		usernameField.setBounds(249, 259, 286, 31);
		frame.getContentPane().add(usernameField);
		usernameField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		passwordField.setEchoChar((char)0);
		passwordField.setBounds(249, 334, 286, 31);
		passwordField.setEchoChar('*');
		frame.getContentPane().add(passwordField);
		
		JButton signinbtn = new JButton("Sign In");
		signinbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				Search.main(null);
				
			}
		});
		signinbtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		signinbtn.setCursor(cursor);
		signinbtn.setBounds(488, 429, 124, 38);
		frame.getContentPane().add(signinbtn);
		
		JLabel lblNewLabel = new JLabel("Don't have an account ?");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(249, 524, 163, 21);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel registerlbl = new JLabel("Register now !");
		registerlbl.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				SignUp.main(null);
			}
		});

        registerlbl.setCursor(cursor);
		registerlbl.setForeground(Color.RED);
		registerlbl.setFont(new Font("Tahoma", Font.BOLD, 15));
		registerlbl.setBounds(422, 524, 181, 21);
		frame.getContentPane().add(registerlbl);
		

	}
}
