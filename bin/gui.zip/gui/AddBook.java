package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.ListSelectionModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import java.awt.Component;

public class AddBook {

	private JFrame frame;
	private JTextField isbnField;
	private JTextField titleField;
	private JTextField authField;
	private JTextField publisherField;
	private JTextField priceField;
	private JTextField yearField;
	 String btnname = "Add Book" ;
	private String[] bookinfo = new String[] {"","","","","","",""};
	private String pgTitle = "Add New Book";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddBook window = new AddBook();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AddBook() {
		initialize();
	}
	public AddBook(String x) {
		this.btnname =new String(x);
		initialize();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1367, 756);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel titlelbl = new JLabel(pgTitle);
		titlelbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 30));
		titlelbl.setBounds(31, 22, 206, 52);
		frame.getContentPane().add(titlelbl);
		
		JButton backbtn = new JButton("Back");
		backbtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		backbtn.setBounds(34, 650, 85, 30);
		frame.getContentPane().add(backbtn);
		
		JLabel lblNewLabel = new JLabel("ISBN number");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel.setBounds(74, 158, 153, 37);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblTitle = new JLabel("Title");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblTitle.setBounds(74, 248, 153, 37);
		frame.getContentPane().add(lblTitle);
		
		JLabel lblAuthor = new JLabel("Author");
		lblAuthor.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblAuthor.setBounds(74, 332, 153, 37);
		frame.getContentPane().add(lblAuthor);
		
		JLabel lblPublisher = new JLabel("Publisher");
		lblPublisher.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblPublisher.setBounds(742, 332, 128, 37);
		frame.getContentPane().add(lblPublisher);
		
		JLabel lblPublicationYear = new JLabel("Publication year");
		lblPublicationYear.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblPublicationYear.setBounds(74, 424, 182, 37);
		frame.getContentPane().add(lblPublicationYear);
		
		JLabel lblSellingPrice = new JLabel("Selling price");
		lblSellingPrice.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblSellingPrice.setBounds(74, 528, 182, 37);
		frame.getContentPane().add(lblSellingPrice);
		
		JLabel lblCategory = new JLabel("Category");
		lblCategory.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblCategory.setBounds(742, 424, 182, 37);
		frame.getContentPane().add(lblCategory);
		
		isbnField = new JTextField();
		isbnField.setHorizontalAlignment(SwingConstants.LEFT);
		isbnField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		isbnField.setBounds(288, 166, 266, 34);
		frame.getContentPane().add(isbnField);
		isbnField.setColumns(10);
		
		titleField = new JTextField();
		titleField.setHorizontalAlignment(SwingConstants.LEFT);
		titleField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		titleField.setColumns(10);
		titleField.setBounds(288, 256, 266, 34);
		frame.getContentPane().add(titleField);
		
		authField = new JTextField();
		authField.setHorizontalAlignment(SwingConstants.LEFT);
		authField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		authField.setColumns(10);
		authField.setBounds(288, 340, 266, 34);
		frame.getContentPane().add(authField);
		
		publisherField = new JTextField();
		publisherField.setHorizontalAlignment(SwingConstants.LEFT);
		publisherField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		publisherField.setColumns(10);
		publisherField.setBounds(965, 338, 266, 34);
		frame.getContentPane().add(publisherField);
		
		priceField = new JTextField();
		priceField.setHorizontalAlignment(SwingConstants.LEFT);
		priceField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		priceField.setColumns(10);
		priceField.setBounds(288, 536, 266, 34);
		frame.getContentPane().add(priceField);
		
		yearField = new JTextField();
		yearField.setHorizontalAlignment(SwingConstants.LEFT);
		yearField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		yearField.setColumns(10);
		yearField.setBounds(288, 432, 266, 34);
		frame.getContentPane().add(yearField);
		JButton btnNewButton = new JButton(this.btnname);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(1109, 650, 122, 30);
		frame.getContentPane().add(btnNewButton);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Science", "Art", "Religion", "History", "Geography"}));
		comboBox.setBounds(965, 426, 266, 37);
		frame.getContentPane().add(comboBox);
		
		JLabel lblMinimumQuantity = new JLabel("Minimum quantity");
		lblMinimumQuantity.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblMinimumQuantity.setBounds(742, 530, 243, 37);
		frame.getContentPane().add(lblMinimumQuantity);
		
		JSpinner spinner = new JSpinner();
		spinner.setAlignmentX(Component.LEFT_ALIGNMENT);
		spinner.setFont(new Font("Tahoma", Font.PLAIN, 20));
		spinner.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		spinner.setBounds(965, 533, 101, 30);
		frame.getContentPane().add(spinner);
	}
}
