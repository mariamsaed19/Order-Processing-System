package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CheckOut extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CheckOut frame = new CheckOut();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CheckOut() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 702, 383);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(0, 0, 102));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		setTitle("Check Out");
		
		JTextField cardNoTextField = new JTextField();
		cardNoTextField.setFont(new Font("Nirmala UI Semilight", Font.PLAIN, 15));
		cardNoTextField.setBounds(273, 57, 330, 42);
		cardNoTextField.setColumns(10);
		contentPane.add(cardNoTextField);
		
		JLabel cardNoLbl = new JLabel("Credit card number");
		cardNoLbl.setLabelFor(cardNoTextField);
		cardNoLbl.setHorizontalAlignment(SwingConstants.CENTER);
		cardNoLbl.setForeground(new Color(255, 255, 51));
		cardNoLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		cardNoLbl.setBounds(43, 57, 187, 42);
		contentPane.add(cardNoLbl);
		
		JLabel lblCreditCardExpiry = new JLabel("Credit card expiry date");
		lblCreditCardExpiry.setHorizontalAlignment(SwingConstants.CENTER);
		lblCreditCardExpiry.setForeground(new Color(255, 255, 51));
		lblCreditCardExpiry.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		lblCreditCardExpiry.setBounds(43, 140, 187, 42);
		contentPane.add(lblCreditCardExpiry);
		
		JComboBox<String> year = new JComboBox<String>();
		year.setToolTipText("select a year");
		year.setFont(new Font("Nirmala UI Semilight", Font.PLAIN, 18));
		year.setModel(new DefaultComboBoxModel<String>(new String[] {"2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030"}));
		year.setBounds(519, 140, 84, 42);
		contentPane.add(year);
		
		JComboBox<String> month = new JComboBox<String>();
		month.setToolTipText("select a month");
		month.setModel(new DefaultComboBoxModel<String>(new String[] {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}));
		month.setFont(new Font("Nirmala UI Semilight", Font.PLAIN, 18));
		month.setBounds(348, 140, 84, 42);
		contentPane.add(month);
		
		JLabel monthLbl = new JLabel("Month");
		monthLbl.setForeground(new Color(255, 255, 255));
		monthLbl.setHorizontalAlignment(SwingConstants.CENTER);
		monthLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		monthLbl.setLabelFor(month);
		monthLbl.setBounds(272, 140, 66, 42);
		contentPane.add(monthLbl);
		
		JLabel lblYear = new JLabel("Year");
		lblYear.setHorizontalAlignment(SwingConstants.CENTER);
		lblYear.setForeground(Color.WHITE);
		lblYear.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		lblYear.setBounds(443, 140, 66, 42);
		contentPane.add(lblYear);
		
		JButton btnNewButton = new JButton("Confirm");
		btnNewButton.addActionListener(new ActionListener() {	//******************************* confirm order *******************
			public void actionPerformed(ActionEvent e) {
				//TODO : perform checks in db
				dispose();
			}
		});
		btnNewButton.setForeground(new Color(153, 0, 102));
		btnNewButton.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		btnNewButton.setBounds(290, 243, 111, 42);
		contentPane.add(btnNewButton);
	}

}
