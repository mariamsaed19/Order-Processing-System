package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;


import javax.swing.event.ListSelectionEvent;
import javax.swing.JTextArea;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Search {

	private JFrame frame;
	private JTextField searchTextField;
	private JLabel title;
	private JComboBox<String> searchByComboBox;
	private JLabel searchByLbl;
	private JLabel searchForLbl;
	private JScrollPane searchResultScrollPane;
	private JList<CartItem> searchResultList;
	private JLabel searchResultLbl;
	private JButton addToCartBtn;
	private DefaultListModel<CartItem> cart;
	private JButton viewCartBtn;
	private JButton searchBtn;
	private JLabel isbnLbl;
	private JLabel bookTitleLbl;
	private JLabel authorLbl;
	private JLabel publisherLbl;
	private JLabel categoryLbl;
	private JLabel priceLbl;
	private JLabel isbn;
	private JLabel bookTitle;
	private JLabel author;
	private JLabel publisher;
	private JLabel category;
	private JLabel price;
	private JLabel quantityLbl;
	private JButton viewProfileBtn;
	private JButton orderBtn;
	private JButton promotionBtn;
	private JButton modifyBook;
	//private int cartTotal = 0;  //TODO

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search window = new Search();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Search() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 51, 102));
		frame.getContentPane().setLayout(null);
		//Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		//frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
		frame.setBounds(100, 100, 1121, 776);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Home page");
		
		title = new JLabel("Search For Books");
		title.setForeground(Color.GREEN);
		title.setBackground(Color.YELLOW);
		title.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 30));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setToolTipText("user's shopping cart");
		title.setBounds(0, 0, 391, 78);
		frame.getContentPane().add(title);
		
		searchByComboBox = new JComboBox<String>();
		searchByComboBox.setToolTipText("search by");
		searchByComboBox.setFont(new Font("Nirmala UI Semilight", Font.PLAIN, 15));
		DefaultComboBoxModel<String> searchBy = new DefaultComboBoxModel<String>(new String[] {"ISBN", "Title", "Author", "Publisher", "Category"});   //TODO
		searchByComboBox.setModel(searchBy);
		searchByComboBox.setBounds(117, 154, 315, 40);
		frame.getContentPane().add(searchByComboBox);
		
		searchByLbl = new JLabel("Search by");
		searchByLbl.setForeground(Color.YELLOW);
		searchByLbl.setHorizontalAlignment(SwingConstants.CENTER);
		searchByLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 15));
		searchByLbl.setLabelFor(searchByComboBox);
		searchByLbl.setBounds(10, 154, 97, 40);
		frame.getContentPane().add(searchByLbl);
		
		searchTextField = new JTextField();
		searchTextField.setToolTipText("Enter something to search for");
		searchTextField.setFont(new Font("Nirmala UI Semilight", Font.PLAIN, 15));
		searchTextField.setBackground(Color.WHITE);
		searchTextField.setBounds(117, 105, 315, 40);
		frame.getContentPane().add(searchTextField);
		searchTextField.setColumns(10);
		
		searchForLbl = new JLabel("Search for");
		searchForLbl.setLabelFor(searchTextField);
		searchForLbl.setHorizontalAlignment(SwingConstants.CENTER);
		searchForLbl.setForeground(Color.YELLOW);
		searchForLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 15));
		searchForLbl.setBounds(10, 104, 97, 40);
		frame.getContentPane().add(searchForLbl);
		
		searchResultScrollPane = new JScrollPane();
		searchResultScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		searchResultScrollPane.setToolTipText("select one or more items to add to cart");
		searchResultScrollPane.setBounds(117, 236, 456, 363);
		frame.getContentPane().add(searchResultScrollPane);
		
		searchResultList = new JList<CartItem>();
		searchResultList.addListSelectionListener(new ListSelectionListener() {		// **********************************  show book info when list item is selected ************************
			public void valueChanged(ListSelectionEvent e) {
				CartItem c = searchResultList.getSelectedValue();
				isbn.setText(String.valueOf(c.getIsbn()));
				bookTitle.setText(c.getTitle());
				bookTitle.setToolTipText(c.getTitle());
				author.setText(c.getAuthor());
				publisher.setText(c.getPublisher());
				price.setText(c.getPrice() + " L.E.");
				category.setText(c.getCategory());
			}
		});
		searchResultList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		searchResultList.setVisibleRowCount(10);
		searchResultScrollPane.setViewportView(searchResultList);
		searchResultList.setToolTipText("select an item to add to cart");
		searchResultList.setFont(new Font("Nirmala UI Semilight", Font.PLAIN, 18));
		searchResultList.setBorder(new LineBorder(new Color(255, 255, 0)));
		searchResultList.setBackground(new Color(0, 153, 204));
		
		//TODO
		
		searchResultList.setModel(Main.getSearchResult());

		searchResultLbl = new JLabel("Results");
		searchResultLbl.setLabelFor(searchResultScrollPane);
		searchResultLbl.setHorizontalAlignment(SwingConstants.CENTER);
		searchResultLbl.setForeground(Color.YELLOW);
		searchResultLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 15));
		searchResultLbl.setBounds(10, 236, 97, 40);
		frame.getContentPane().add(searchResultLbl);
		
		addToCartBtn = new JButton("Add to cart");
		addToCartBtn.addActionListener(new ActionListener() {  //*************************************** add to cart ***************************************************
			public void actionPerformed(ActionEvent e) {
				/*int[] selected = searchResultList.getSelectedIndices();
				for (int i = 0; i < selected.length; i++) {
				      CartItem item = searchResultList.getModel().getElementAt(selected[i]);
				      cart.addElement(item);
				      cartTotal += item.getPrice();
				}
				//cartLbl.setText("Cart  :  " + cartTotal + "  L.E.");
				searchResultList.clearSelection();*/
			}
		});
		addToCartBtn.setForeground(new Color(0, 0, 102));
		addToCartBtn.setBackground(Color.WHITE);
		addToCartBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		addToCartBtn.setToolTipText("click to add selected items to the cart");
		addToCartBtn.setBounds(725, 633, 139, 40);
		frame.getContentPane().add(addToCartBtn);
		cart = new DefaultListModel<CartItem>();
		
		viewCartBtn = new JButton("View Cart");
		viewCartBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				Cart.main(null);
			}
		});

		viewCartBtn.setForeground(new Color(0, 0, 102));
		viewCartBtn.setToolTipText("go to cart");
		viewCartBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		viewCartBtn.setBackground(Color.WHITE);
		viewCartBtn.setBounds(910, 37, 139, 40);
		frame.getContentPane().add(viewCartBtn);
		
		searchBtn = new JButton("search");
		searchBtn.setToolTipText("search");
		searchBtn.setForeground(new Color(0, 0, 102));
		searchBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		searchBtn.setBackground(Color.WHITE);
		searchBtn.setBounds(476, 153, 97, 40);
		frame.getContentPane().add(searchBtn);
		
		isbnLbl = new JLabel("ISBN number : ");
		isbnLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		isbnLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		isbnLbl.setForeground(Color.WHITE);
		isbnLbl.setBounds(644, 230, 156, 27);
		frame.getContentPane().add(isbnLbl);
		
		bookTitleLbl = new JLabel("Book Title : ");
		bookTitleLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		bookTitleLbl.setForeground(Color.WHITE);
		bookTitleLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		bookTitleLbl.setBounds(644, 280, 156, 27);
		frame.getContentPane().add(bookTitleLbl);
		
		authorLbl = new JLabel("Author : ");
		authorLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		authorLbl.setForeground(Color.WHITE);
		authorLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		authorLbl.setBounds(644, 330, 156, 27);
		frame.getContentPane().add(authorLbl);
		
		publisherLbl = new JLabel("Publisher : ");
		publisherLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		publisherLbl.setForeground(Color.WHITE);
		publisherLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		publisherLbl.setBounds(644, 380, 156, 27);
		frame.getContentPane().add(publisherLbl);
		
		categoryLbl = new JLabel("Category : ");
		categoryLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		categoryLbl.setForeground(Color.WHITE);
		categoryLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		categoryLbl.setBounds(644, 430, 156, 27);
		frame.getContentPane().add(categoryLbl);
		
		priceLbl = new JLabel("Price : ");
		priceLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		priceLbl.setForeground(Color.WHITE);
		priceLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		priceLbl.setBounds(644, 480, 156, 27);
		frame.getContentPane().add(priceLbl);
		
		isbn = new JLabel("_________");
		isbn.setHorizontalAlignment(SwingConstants.CENTER);
		isbn.setForeground(Color.WHITE);
		isbn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		isbn.setBounds(830, 230, 156, 27);
		frame.getContentPane().add(isbn);
		
		bookTitle = new JLabel("_________");
		bookTitle.setHorizontalAlignment(SwingConstants.CENTER);
		bookTitle.setForeground(Color.WHITE);
		bookTitle.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		bookTitle.setBounds(830, 280, 156, 27);
		frame.getContentPane().add(bookTitle);
		
		author = new JLabel("_________");
		author.setHorizontalAlignment(SwingConstants.CENTER);
		author.setForeground(Color.WHITE);
		author.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		author.setBounds(830, 330, 156, 27);
		frame.getContentPane().add(author);
		
		publisher = new JLabel("_________");
		publisher.setHorizontalAlignment(SwingConstants.CENTER);
		publisher.setForeground(Color.WHITE);
		publisher.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		publisher.setBounds(830, 380, 156, 27);
		frame.getContentPane().add(publisher);
		
		category = new JLabel("_________");
		category.setHorizontalAlignment(SwingConstants.CENTER);
		category.setForeground(Color.WHITE);
		category.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		category.setBounds(830, 430, 156, 27);
		frame.getContentPane().add(category);
		
		price = new JLabel("_________");
		price.setHorizontalAlignment(SwingConstants.CENTER);
		price.setForeground(Color.WHITE);
		price.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		price.setBounds(830, 480, 156, 27);
		frame.getContentPane().add(price);
		
		quantityLbl = new JLabel("specify quantity");
		quantityLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		quantityLbl.setForeground(Color.WHITE);
		quantityLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		quantityLbl.setBounds(644, 572, 156, 27);
		frame.getContentPane().add(quantityLbl);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(1, 1, null, 1));
		spinner.setBounds(856, 572, 97, 27);
		frame.getContentPane().add(spinner);
		
		JButton logOutBtn = new JButton("Log out");
		logOutBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				SignIn.main(null);
			}
		});
		logOutBtn.setToolTipText("log out");
		logOutBtn.setForeground(new Color(0, 0, 102));
		logOutBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		logOutBtn.setBackground(Color.WHITE);
		logOutBtn.setBounds(10, 689, 139, 40);
		frame.getContentPane().add(logOutBtn);
		
		viewProfileBtn = new JButton("View Profile");
		viewProfileBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				Profile.main(null);
			}
		});

		viewProfileBtn.setToolTipText("go to cart");
		viewProfileBtn.setForeground(new Color(0, 0, 102));
		viewProfileBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		viewProfileBtn.setBackground(Color.WHITE);
		viewProfileBtn.setBounds(744, 38, 139, 40);
		frame.getContentPane().add(viewProfileBtn);
		
		orderBtn = new JButton("Order");
		orderBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				Orders.main(null);
			}
		});

		orderBtn.setToolTipText("go to cart");
		orderBtn.setForeground(new Color(0, 0, 102));
		orderBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		orderBtn.setBackground(Color.WHITE);
		orderBtn.setBounds(744, 106, 139, 40);
		frame.getContentPane().add(orderBtn);
		
		promotionBtn = new JButton("Promotion");
		promotionBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				Promotion.main(null);
			}
		});
		promotionBtn.setToolTipText("go to cart");
		promotionBtn.setForeground(new Color(0, 0, 102));
		promotionBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		promotionBtn.setBackground(Color.WHITE);
		promotionBtn.setBounds(910, 105, 139, 40);
		frame.getContentPane().add(promotionBtn);
		
		modifyBook = new JButton("Modify book");
		modifyBook.setToolTipText("click to add selected items to the cart");
		modifyBook.setForeground(new Color(0, 0, 102));
		modifyBook.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		modifyBook.setBackground(Color.WHITE);
		modifyBook.setBounds(274, 633, 139, 40);
		frame.getContentPane().add(modifyBook);
		
	}
	
	public void setVisible(boolean b) {
		frame.setVisible(b);
	}
}
