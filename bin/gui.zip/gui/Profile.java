package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextPane;
import javax.swing.JToggleButton;
import javax.swing.JEditorPane;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Profile {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Profile window = new Profile();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Profile() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame.setBackground(Color.LIGHT_GRAY);
		frame.setBounds(100, 100, 1110, 592);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JEditorPane editorPane = new JEditorPane();
		editorPane.setEditable(false);
		editorPane.setEnabled(false);
		editorPane.setBackground(Color.WHITE);
		editorPane.setFont(new Font("Tahoma", Font.PLAIN, 16));
		editorPane.setBounds(365, 106, 383, 45);
		frame.getContentPane().add(editorPane);
		
		JButton EditProfileButton = new JButton("Edit Profile");
		EditProfileButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		EditProfileButton.setBounds(842, 106, 162, 53);
		frame.getContentPane().add(EditProfileButton);
		
		JLabel FirstnameLabel = new JLabel("Firstname");
		FirstnameLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		FirstnameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		FirstnameLabel.setBounds(221, 106, 123, 32);
		frame.getContentPane().add(FirstnameLabel);
		
		JEditorPane editorPane_1 = new JEditorPane();
		editorPane_1.setEnabled(false);
		editorPane_1.setEditable(false);
		editorPane_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		editorPane_1.setBounds(365, 193, 383, 41);
		frame.getContentPane().add(editorPane_1);
		
		JEditorPane editorPane_2 = new JEditorPane();
		editorPane_2.setEnabled(false);
		editorPane_2.setEditable(false);
		editorPane_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		editorPane_2.setBounds(365, 276, 383, 41);
		frame.getContentPane().add(editorPane_2);
		
		JEditorPane editorPane_3 = new JEditorPane();
		editorPane_3.setEnabled(false);
		editorPane_3.setEditable(false);
		editorPane_3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		editorPane_3.setBounds(365, 356, 383, 38);
		frame.getContentPane().add(editorPane_3);
		
		JLabel LastnameLabel = new JLabel("Lastname");
		LastnameLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		LastnameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		LastnameLabel.setBounds(221, 193, 123, 32);
		frame.getContentPane().add(LastnameLabel);
		
		JLabel mailLabel = new JLabel("E-mail");
		mailLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		mailLabel.setHorizontalAlignment(SwingConstants.CENTER);
		mailLabel.setBounds(221, 276, 123, 32);
		frame.getContentPane().add(mailLabel);
		
		JLabel PhoneLabel = new JLabel("Phone");
		PhoneLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		PhoneLabel.setHorizontalAlignment(SwingConstants.CENTER);
		PhoneLabel.setBounds(221, 356, 123, 32);
		frame.getContentPane().add(PhoneLabel);
		
		JEditorPane dtrpnUserName = new JEditorPane();
		dtrpnUserName.setEditable(false);
		dtrpnUserName.setFont(new Font("Tahoma", Font.PLAIN, 28));
		dtrpnUserName.setText("User Name");
		dtrpnUserName.setBounds(21, 28, 222, 53);
		frame.getContentPane().add(dtrpnUserName);
		
		JEditorPane editorPane_5 = new JEditorPane();
		editorPane_5.setEnabled(false);
		editorPane_5.setEditable(false);
		editorPane_5.setFont(new Font("Tahoma", Font.PLAIN, 16));
		editorPane_5.setBounds(365, 437, 383, 41);
		frame.getContentPane().add(editorPane_5);
		
		JLabel ShippingLabel = new JLabel("Shipping address");
		ShippingLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		ShippingLabel.setHorizontalAlignment(SwingConstants.CENTER);
		ShippingLabel.setBounds(182, 437, 162, 32);
		frame.getContentPane().add(ShippingLabel);
		
		JButton changePasswordButton = new JButton("Change password");
		changePasswordButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		changePasswordButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		changePasswordButton.setBounds(842, 193, 162, 47);
		frame.getContentPane().add(changePasswordButton);
		
		JEditorPane oldpassword = new JEditorPane();
		oldpassword.setEnabled(false);
		oldpassword.setEditable(false);
		oldpassword.setBounds(830, 315, 197, 38);
		oldpassword.setVisible(false);
		frame.getContentPane().add(oldpassword);
		
		JEditorPane newpassword = new JEditorPane();
		newpassword.setEnabled(false);
		newpassword.setEditable(false);
		newpassword.setBounds(830, 394, 196, 38);
		newpassword.setVisible(false);
		frame.getContentPane().add(newpassword);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				Search.main(null);
			}
		});

		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBounds(17, 500, 102, 32);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_6 = new JLabel("Profile");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 32));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(395, 10, 315, 43);
		frame.getContentPane().add(lblNewLabel_6);
	}

	public void setVisible(boolean b) {
		frame.setVisible(b);
	}
}
