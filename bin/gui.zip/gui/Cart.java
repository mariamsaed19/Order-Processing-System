package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import javax.swing.AbstractListModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Cart extends JFrame {

	private JPanel contentPane;
	private JLabel titleLbl;
	private JScrollPane cartScrollPane;
	private JList<CartItem> cartList;
	private JLabel isbnLbl;
	private JLabel isbn;
	private JLabel bookTitleLbl;
	private JLabel bookTitle;
	private JLabel authorLbl;
	private JLabel author;
	private JLabel publisherLbl;
	private JLabel publisher;
	private JLabel categoryLbl;
	private JLabel category;
	private JLabel priceLbl;
	private JLabel price;
	private JButton btnRemoveThisItem;
	private JButton clearBtn;
	private JLabel totalLbl;
	private JButton checkOutBtn;
	private JButton backBtn;
	private int cartTotal;
	private DefaultListModel<CartItem> cart;
	private JLabel quantityLbl;
	private JLabel quantity;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cart frame = new Cart();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cart() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1121, 776);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 51, 102));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		setTitle("Your Cart");
		
		titleLbl = new JLabel("Your Cart");
		titleLbl.setToolTipText("");
		titleLbl.setHorizontalAlignment(SwingConstants.CENTER);
		titleLbl.setForeground(Color.GREEN);
		titleLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 35));
		titleLbl.setBackground(Color.YELLOW);
		titleLbl.setBounds(0, 0, 250, 103);
		contentPane.add(titleLbl);
		
		cartScrollPane = new JScrollPane();
		cartScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		cartScrollPane.setToolTipText("your cart");
		cartScrollPane.setBounds(62, 179, 504, 407);
		contentPane.add(cartScrollPane);
		
		cartList = new JList<CartItem>();
		cartList.addListSelectionListener(new ListSelectionListener() {  // **********************************  show book info when list item is selected ************************
			public void valueChanged(ListSelectionEvent e) {
				try {
					CartItem c = cartList.getSelectedValue();
					isbn.setText(String.valueOf(c.getIsbn()));
					bookTitle.setText(c.getTitle());
					bookTitle.setToolTipText(c.getTitle());
					author.setText(c.getAuthor());
					publisher.setText(c.getPublisher());
					price.setText(c.getPrice() + " L.E.");
					category.setText(c.getCategory());
					quantity.setText(String.valueOf(c.getQuantityInCart()));
				}catch(NullPointerException ex) {
					isbn.setText("_________");
					bookTitle.setText("_________");
					bookTitle.setToolTipText("_________");
					author.setText("_________");
					publisher.setText("_________");
					price.setText("_________");
					category.setText("_________");
					quantity.setText("_________");
				}
			}
		});
		//cart = new DefaultListModel<CartItem>();
		cart = Main.getSearchResult();  //TODO
		cartList.setModel(cart);
		cartScrollPane.setViewportView(cartList);
		cartList.setVisibleRowCount(10);
		cartList.setToolTipText("select an item to add to cart");
		cartList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		cartList.setFont(new Font("Nirmala UI Semilight", Font.PLAIN, 18));
		cartList.setBorder(new LineBorder(new Color(255, 255, 0)));
		cartList.setBackground(new Color(0, 153, 204));
		
		isbnLbl = new JLabel("ISBN number : ");
		isbnLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		isbnLbl.setForeground(Color.WHITE);
		isbnLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		isbnLbl.setBounds(615, 180, 156, 27);
		contentPane.add(isbnLbl);
		
		isbn = new JLabel("_________");
		isbn.setHorizontalAlignment(SwingConstants.CENTER);
		isbn.setForeground(Color.WHITE);
		isbn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		isbn.setBounds(801, 180, 156, 27);
		contentPane.add(isbn);
		
		bookTitleLbl = new JLabel("Book Title : ");
		bookTitleLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		bookTitleLbl.setForeground(Color.WHITE);
		bookTitleLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		bookTitleLbl.setBounds(615, 230, 156, 27);
		contentPane.add(bookTitleLbl);
		
		bookTitle = new JLabel("_________");
		bookTitle.setHorizontalAlignment(SwingConstants.CENTER);
		bookTitle.setForeground(Color.WHITE);
		bookTitle.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		bookTitle.setBounds(801, 230, 156, 27);
		contentPane.add(bookTitle);
		
		authorLbl = new JLabel("Author : ");
		authorLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		authorLbl.setForeground(Color.WHITE);
		authorLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		authorLbl.setBounds(615, 280, 156, 27);
		contentPane.add(authorLbl);
		
		author = new JLabel("_________");
		author.setHorizontalAlignment(SwingConstants.CENTER);
		author.setForeground(Color.WHITE);
		author.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		author.setBounds(801, 280, 156, 27);
		contentPane.add(author);
		
		publisherLbl = new JLabel("Publisher : ");
		publisherLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		publisherLbl.setForeground(Color.WHITE);
		publisherLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		publisherLbl.setBounds(615, 330, 156, 27);
		contentPane.add(publisherLbl);
		
		publisher = new JLabel("_________");
		publisher.setHorizontalAlignment(SwingConstants.CENTER);
		publisher.setForeground(Color.WHITE);
		publisher.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		publisher.setBounds(801, 330, 156, 27);
		contentPane.add(publisher);
		
		categoryLbl = new JLabel("Category : ");
		categoryLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		categoryLbl.setForeground(Color.WHITE);
		categoryLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		categoryLbl.setBounds(615, 380, 156, 27);
		contentPane.add(categoryLbl);
		
		category = new JLabel("_________");
		category.setHorizontalAlignment(SwingConstants.CENTER);
		category.setForeground(Color.WHITE);
		category.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		category.setBounds(801, 380, 156, 27);
		contentPane.add(category);
		
		priceLbl = new JLabel("Price : ");
		priceLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		priceLbl.setForeground(Color.WHITE);
		priceLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		priceLbl.setBounds(615, 430, 156, 27);
		contentPane.add(priceLbl);
		
		price = new JLabel("_________");
		price.setHorizontalAlignment(SwingConstants.CENTER);
		price.setForeground(Color.WHITE);
		price.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		price.setBounds(801, 430, 156, 27);
		contentPane.add(price);
		
		btnRemoveThisItem = new JButton("Remove this item");
		btnRemoveThisItem.addActionListener(new ActionListener() {		 //***********************************************   clear cart list   *****************************************
			public void actionPerformed(ActionEvent e) {
				try {
					int index = cartList.getSelectedIndex();
					CartItem c = cartList.getSelectedValue();
					cartTotal -= c.getPrice();
					cart.removeElementAt(index);
					totalLbl.setText("Cart  :  " + cartTotal + "  L.E.");
				}catch(NullPointerException ex) {
					
				}
				
			}
		});
		btnRemoveThisItem.setToolTipText("click to remove selected items from the cart");
		btnRemoveThisItem.setForeground(new Color(0, 0, 102));
		btnRemoveThisItem.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		btnRemoveThisItem.setBackground(Color.WHITE);
		btnRemoveThisItem.setBounds(748, 550, 181, 40);
		contentPane.add(btnRemoveThisItem);
		
		clearBtn = new JButton("Clear cart");
		clearBtn.addActionListener(new ActionListener() {		//***********************************************   clear cart list   *****************************************
			public void actionPerformed(ActionEvent e) {
				cart.removeAllElements();
				cartTotal = 0;
				totalLbl.setText("Total  :  " + cartTotal + "  L.E.");
			}
		});
		clearBtn.setToolTipText("click to clear all items in the cart");
		clearBtn.setForeground(new Color(0, 0, 102));
		clearBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		clearBtn.setBackground(Color.WHITE);
		clearBtn.setBounds(245, 613, 139, 40);
		contentPane.add(clearBtn);
		
		totalLbl = new JLabel("Total  :  0  L.E.");
		totalLbl.setHorizontalAlignment(SwingConstants.CENTER);
		totalLbl.setForeground(Color.YELLOW);
		totalLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 25));
		totalLbl.setBounds(202, 117, 231, 52);
		contentPane.add(totalLbl);
		
		checkOutBtn = new JButton("Check out");
		checkOutBtn.addActionListener(new ActionListener() {	//******************************* go to check out page ***********************
			public void actionPerformed(ActionEvent e) {
				CheckOut checkoutPage = new CheckOut();
				checkoutPage.setVisible(true);
			}
		});
		checkOutBtn.setToolTipText("check out");
		checkOutBtn.setForeground(new Color(0, 0, 102));
		checkOutBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		checkOutBtn.setBackground(Color.WHITE);
		checkOutBtn.setBounds(910, 37, 139, 40);
		contentPane.add(checkOutBtn);
		
		backBtn = new JButton("Back");
		backBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				Search.main(null);
			}
		});

		backBtn.setToolTipText("back to search page");
		backBtn.setForeground(new Color(0, 0, 102));
		backBtn.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 18));
		backBtn.setBackground(Color.WHITE);
		backBtn.setBounds(10, 689, 139, 40);
		contentPane.add(backBtn);
		
		quantityLbl = new JLabel("Quantity in cart : ");
		quantityLbl.setHorizontalAlignment(SwingConstants.RIGHT);
		quantityLbl.setForeground(Color.WHITE);
		quantityLbl.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		quantityLbl.setBounds(604, 467, 181, 27);
		contentPane.add(quantityLbl);
		
		quantity = new JLabel("_________");
		quantity.setHorizontalAlignment(SwingConstants.CENTER);
		quantity.setForeground(Color.WHITE);
		quantity.setFont(new Font("Nirmala UI Semilight", Font.BOLD, 20));
		quantity.setBounds(801, 467, 156, 27);
		contentPane.add(quantity);
	}
}
